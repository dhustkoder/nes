# nes-gamedev-examples

This repository <http://github.com/algofoogle/nes-gamedev-examples> is to support a series of
articles on NES (Nintendo Entertainment System) game development, to be published at
[anton.maurovic.com](http://anton.maurovic.com/). The initial article can be found at:
<http://anton.maurovic.com/posts/nintendo-nes-gamedev-part-1-setting-up/>

Expect this repository to grow over time, as the articles in the series are published.
