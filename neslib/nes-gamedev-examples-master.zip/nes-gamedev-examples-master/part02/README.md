# part02 -- Nintendo (NES) Gamedev, part 2: Basic I/O

The contents of this `part02` directory are associated with the following article:

*	<http://anton.maurovic.com/posts/nintendo-nes-gamedev-part-2-basic-io/> -- **NOT YET RELEASED**

This part contains just the following:

*	`ex01-controller-test` -- Built on `part01/ex02-asm-example`, this shows the key parts of input
	and output on the NES: Video, audio, and reading the controller.

